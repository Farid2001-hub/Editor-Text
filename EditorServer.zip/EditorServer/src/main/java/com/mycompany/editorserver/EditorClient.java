/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorserver;

/**
 *
 * @author luk
 */
public class EditorClient {
    EditorFile file;
    int lockedLine;
    
    public EditorClient(EditorFile file) {
        this.file = file;
        lockedLine = 0;
    }
    
    public void lockLine(int l) throws LockedLineException {
        if (lockedLine != 0) {
            throw new LockedLineException();
        }
        file.addClient(this, l);
    }

    public void modifyLockedLine(String contents) throws NoLockedLineException {
        if (lockedLine == 0) {
            throw new NoLockedLineException();
        }
        file.modifyLine(lockedLine, contents);
    }

    public void unlockLine() throws NoLockedLineException {
        if (lockedLine == 0) {
            throw new NoLockedLineException();
        }
        file.removeClient(this);
    }

}
