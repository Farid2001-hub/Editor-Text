/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorserver;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author luk
 */
public class EditorFile {
    String path;
    ArrayList<EditorClient> clients;
    
    public EditorFile(String path) {
        this.path = path;
        clients = new ArrayList();
        try {
            File file = new File(path);
            if (!file.exists())
                file.createNewFile();
        } catch (IOException ex) {
            Logger.getLogger(EditorFile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void addClient(EditorClient client, int line) throws LockedLineException {
        for (EditorClient c : clients) {
            if (c.lockedLine == line)
                throw new LockedLineException();
        }
        clients.add(client);
        client.lockedLine = line;
    }
    
    public void removeClient(EditorClient client) {
        client.lockedLine = 0;
        clients.remove(client);
    }
    
    public synchronized String getLine(int l) {
        try {
            BufferedReader reader;
            reader = new BufferedReader(new FileReader(path));
            String line;
            int i = 0;
            while ((line = reader.readLine()) != null) {
                i++;
                if (i == l)
                    return line;
            }
            reader.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EditorFile.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EditorFile.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }
    
    public synchronized String getContents() {
        try {
            BufferedReader reader;
            reader = new BufferedReader(new FileReader(path));
            StringBuffer buffer = new StringBuffer();
            String line;
            while ((line = reader.readLine()) != null) {
                line = line + System.lineSeparator();
                buffer.append(line);
            }
            reader.close();
            return buffer.toString();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EditorFile.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EditorFile.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }
    
    public synchronized void modifyLine(int l, String contents) {
        try {
            BufferedReader reader;
            reader = new BufferedReader(new FileReader(path));
            StringBuffer buffer = new StringBuffer();
            String line;
            int i = 0;
            while ((line = reader.readLine()) != null) {
                i++;
                if (i == l)
                    line = contents;
                line = line + System.lineSeparator();
                buffer.append(line);
            }
            while (i < l) {
                i++;
                if (i == l)
                    buffer.append(contents);
                buffer.append('\n');
            }
            reader.close();
            FileWriter writer;
            writer = new FileWriter(path);
            writer.append(buffer);
            writer.flush();
            writer.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EditorFile.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EditorFile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
