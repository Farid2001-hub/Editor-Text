/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author luk
 */
public class EditorServerThread extends Thread {
    Socket socket;
    EditorServer server;
    EditorClient client;
    
    public EditorServerThread(EditorServer server, Socket socket) {
        this.server = server;
        this.socket = socket;
        this.client = null;
    }
    
    @Override
    public void run() {
        try {
            BufferedReader in;
            PrintWriter out;
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            while (true) {
                String command = in.readLine();
                System.out.println("command: " + command);
                if (command.startsWith("open")) {
                    EditorFile file = server.getFile(command.substring(5));
                    client = new EditorClient(file);
                    server.clients.add(client);
                    out.println("OK");
                }
                else if (command.startsWith("lock")) {
                    if (client != null) {
                        try {
                            int line = Integer.parseInt(command.substring(5));
                            client.lockLine(line);
                            out.println("OK");
                        } catch (LockedLineException ex) {
                            Logger.getLogger(EditorServerThread.class.getName()).log(Level.SEVERE, null, ex);
                            out.println("NOK (already locked)");
                        }
                    }
                }
                else if (command.startsWith("edit")) {
                    if (client != null) {
                        try {
                            client.modifyLockedLine(command.substring(5));
                            out.println("OK");
                        } catch (NoLockedLineException ex) {
                            Logger.getLogger(EditorServerThread.class.getName()).log(Level.SEVERE, null, ex);
                            out.println("NOK (not locked)");
                        }
                    }
                }
                else if (command.startsWith("unlock")) {
                    if (client != null) {
                        try {
                            client.unlockLine();
                            out.println("OK");
                        } catch (NoLockedLineException ex) {
                            Logger.getLogger(EditorServerThread.class.getName()).log(Level.SEVERE, null, ex);
                            out.println("NOK (not locked)");
                        }
                    }
                }
                else if (command.startsWith("refresh")) {
                    String[] contents = client.file.getContents().split(System.lineSeparator());
                    out.println(contents.length);
                    for (String s : contents) {
                        out.println(s);
                    }
                }
                else if (command.equals("close")) {
                    if (client != null) {
                        client.file.removeClient(client);
                        server.clients.remove(client);
                        client = null;
                    }
                    out.println("OK");
                    socket.close();
                    break;
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(EditorServerThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
