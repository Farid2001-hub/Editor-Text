/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.editorserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author luk
 */
public class EditorServer {
    
    ArrayList<EditorFile> files;
    ArrayList<EditorClient> clients;
    
    public EditorServer() {
        files = new ArrayList();
        clients = new ArrayList();
    }
    
    public EditorFile getFile(String path) {
        for (EditorFile f : files) {
            if (f.path.equals(path))
                return f;
        }
        EditorFile file = new EditorFile(path);
        files.add(file);
        return file;
    }

    public static void main(String[] args) {
        System.out.println("Waiting for connections on port 5000");
        EditorServer server = new EditorServer();
        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            while (true) {
                Socket socket = serverSocket.accept();
                EditorServerThread thread = new EditorServerThread(server, socket);
                thread.start();
            }
        } catch (IOException ex) {
            Logger.getLogger(EditorServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
