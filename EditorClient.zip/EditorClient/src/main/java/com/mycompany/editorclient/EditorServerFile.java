/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.editorclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author luk
 */
public class EditorServerFile {
    Socket socket;
    BufferedReader in;
    PrintWriter out;
    
    public EditorServerFile(String serverName, int port, String fileName) throws ServerErrorException {
        try {
            socket = new Socket(serverName, port);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            out.println("open " + fileName);
            if (!in.readLine().startsWith("OK")) {
                throw new ServerErrorException();
            }
        } catch (IOException ex) {
            throw new ServerErrorException();
        }
    }
    
    public boolean lock(int i) throws ServerErrorException {
        try {
            out.println("lock " + i);
            return in.readLine().startsWith("OK");
        } catch (IOException ex) {
            throw new ServerErrorException();
        }
    }

    public boolean edit(String contents) throws ServerErrorException {
        try {
            out.println("edit " + contents);
            return in.readLine().startsWith("OK");
        } catch (IOException ex) {
            throw new ServerErrorException();
        }
    }
    
    public boolean unlock() throws ServerErrorException {
        try {
            out.println("unlock");
            return in.readLine().startsWith("OK");
        } catch (IOException ex) {
            throw new ServerErrorException();
        }
    }
    
    public String[] refresh() throws ServerErrorException {
        String[] contents = null;
        try {
            out.println("refresh");
            int nbLines = Integer.parseInt(in.readLine());
            contents = new String[nbLines];
            for (int i = 0; i < nbLines; i++) {
                contents[i] = in.readLine();
            }
        } catch (IOException ex) {
            throw new ServerErrorException();
        }
        return contents;
    }

    public boolean close() throws ServerErrorException {
        try {
            out.println("close");
            return in.readLine().startsWith("OK");
        } catch (IOException ex) {
            throw new ServerErrorException();
        }
    } 
}
